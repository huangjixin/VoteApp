import React, { Component } from 'react';
import { HashRouter as Router, Route, Switch } from "react-router-dom";
import './App.css';
import Login from './modules/login/Login';
import Home from './modules/home/Home';
import Vote from './modules/home/Vote';
import Result from './modules/home/Result'

class App extends Component {
  render() {
    return (
      <Router>
        <div className="App">
          <Switch>
            <Route exact path='/home' component={Home}></Route>
            <Route exact path='/voted' component={Vote}></Route>
            <Route exact path='/result' component={Result}></Route>
            <Route exact path='/' component={Login}></Route>
          </Switch>
        </div>
      </Router>
    );
  }
}

export default App;
