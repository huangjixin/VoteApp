import React, { Component } from 'react';
import Base from '../../resource/Base';
import '../../css/login/Login.css';

const baseUrl = Base.baseUrl;
class Login extends Component {
    constructor(props) {
        super(props);
        this.state = {
            mobile: '',
            isClick: false,
            isSend: false,
            code: '',
            isShowTips: 'none'
        }
    }


    render() {
        return (
            <div className='Login'>
                <h1>登录页面</h1>
                <form onSubmit={this.handleSubmit}>
                    <div>
                        <label style={{
                            fontSize: 18
                        }}>
                            电话号码:{'  '}
                            <input
                                style={{
                                    width: 200,
                                    height: 30
                                }}
                                className='LoginMobile'
                                type="text"
                                onChange={this.setMobile} ></input>
                        </label>
                    </div>
                    <br />
                    <div>
                        <div style={{
                            display: 'flex',
                            // flexDirection: 'column',
                            alignItems: 'center',
                            justifyContent: 'center',
                        }}>
                            <label style={{
                                fontSize: 18,

                            }}>
                                验证码:{'  '}
                                <input
                                    style={{
                                        width: 100,
                                        height: 30
                                    }}
                                    className='LoginMobile'
                                    type="text"
                                    onChange={this.setCode} ></input>

                            </label>
                            <span
                                style={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    width: 50,
                                    height: 36,
                                    backgroundColor: '#2BCDE5',
                                    color: 'white',
                                    marginLeft: 15
                                }}
                                onClick={this.getVerifyCode}>发送</span>
                        </div>
                        <div>
                            <span style={{
                                color: 'red',
                                display: this.state.isShowTips
                            }}>已发送</span>
                        </div>
                    </div>
                    <div style={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        paddingTop: 20,
                        paddingBottom: 20
                    }}>
                        <input style={{
                            width: 200,
                            height: 50,
                            backgroundColor: '#2BCDE5',
                            color: '#FFFFFF',
                            fontSize: 18,
                            borderRadius: 50
                        }}
                            type='submit'
                            value='登录' />
                    </div>
                </form>
            </div>
        );
    }

    setCode = (event) => {
        this.setState({ code: event.target.value });
    }

    getVerifyCode = () => {
        if (this.state.isSend) {
            return;
        }

        if (this.state.mobile == '' || isNaN(this.state.mobile)) {
            alert('请检查电话号码');
            return;
        }


        this.state.isSend = true;

        let url = baseUrl + '/user/getVerifyCode?mobil=' + this.state.mobile;
        this.setState({ isShowTips: 'block' }, () => {
            fetch(url, {
                credentials: 'include',
                xhrFields: { withCredentials: true },
                crossDomain: true
            }).then(res => {
                if (typeof res == 'undefined' || res == null || res == '') {
                    alert('发送失败');
                } else {
                    return res.json();
                }
            }).then(data => {
                if (typeof data == 'undefined' || data == null) {
                    alert('发送失败');
                } else {
                    if (data.code == 200) {

                    } else {
                        alert(data.message);
                    }
                }
                this.state.isSend = false;
            }).catch(e => {
                this.state.isSend = false;
                alert(e);
            });
        });
    }

    handleSubmit = (event) => {

        //点击过一次，直接返回
        if (this.state.isClick) {
            return;
        }

        if (this.state.mobile == '' || isNaN(this.state.mobile)) {
            alert('请检查电话号码');
            event.preventDefault();
            return;
        }

        if (this.state.code == '' || isNaN(this.state.code)) {
            alert('请检查验证码');
            event.preventDefault();
            return;
        }


        this.state.isClick = true;

        this.loginFetch();

        // let path = {
        //     pathname: '/home'
        // }
        // this.props.history.push(path);

        // 阻止默认事件
        event.preventDefault();
    }

    loginFetch = () => {
        let url = baseUrl + '/user/loginWithVerifyCode';
        let mobile = this.state.mobile;
        let code = this.state.code;
        let data = 'mobil=' + mobile + '&verifyCode=' + code;

        // 'application/x-www-form-urlencoded'
        fetch(
            url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: data,
                xhrFields: { withCredentials: true },
                credentials: 'include',
                crossDomain: true
            }
        ).then(res => {
            if (typeof res == 'undefined' || res == null || res == '') {
                this.state.isClick = false;
                alert('登录失败');
            } else {
                return res.json();
            }
        }).then(data => {
            if (typeof data != 'undefined' && data != null && data.code == 200) {
                let storage = window.sessionStorage;
                storage.setItem("user", (JSON.stringify(data.data)));
                let path = {
                    pathname: '/home'
                }
                this.props.history.push(path);
            } else if (typeof data != 'undefined' && data != null && data.code == 2000) {
                let storage = window.sessionStorage;
                storage.setItem("user", (JSON.stringify(data.data)));
                let path = {
                    pathname: '/voted'
                }
                this.props.history.push(path);
            } else {
                alert(data.message);
            }
            this.state.isClick = false;
        }).catch(e => {
            this.state.isClick = false;
            alert(e);
        });
    }

    setMobile = (event) => {
        this.setState({ mobile: event.target.value });
    }
}

export default Login;