import React, { Component } from 'react';
import Base from '../../resource/Base';

const baseUrl = Base.baseUrl;
let user = null;
let storage = window.sessionStorage;
class Vote extends Component {

    constructor(props) {
        super(props);
        this.state = {
            result: [],
            isLeader: 0
        }
        let data = storage.getItem('user')
        if (typeof data != 'undefined' && data != null) {
            user = JSON.parse(data);
        }
    }


    componentDidMount = () => {
        if (user != null) {
            this.setState({ isLeader: user.isLeader });
        }
        this.selfVotedRequest();
    }

    selfVotedRequest = () => {
        if (typeof user != 'undefined' && user != null) {
            let userId = user.id;
            let url = baseUrl + '/vote/selectVoteByUserId?userId=' + userId;

            fetch(url, {
                credentials: 'include',
                xhrFields: { withCredentials: true },
                crossDomain: true
            }).then((response) => { // 数据解析方式

                if (typeof response == 'undefined' || response == null || response.status == 404) {
                    //请求不到数据
                    return '数据错误';
                } else {
                    return response.json();
                }
            }).then((responseData) => { // 获取到的数据处理
                // 请求不到数据，直接返回
                if (responseData == '数据错误') {
                    alert('请求不到数据');
                    return;
                }
                this.setState({ result: responseData });
            }).catch((error) => { // 错误处理
                if (error) {
                    alert(error + "");
                }
            });
        } else {
            alert('用户没有登录');
        }
    }

    goToVote = () => {
        let path = {
            pathname: '/home'
        }
        this.props.history.push(path);
    }



    render() {

        let contenView = [];
        let data = this.state.result;
        if (typeof data == 'undefined' || data == null || data == [] || data.length == 0) {
            contenView =
                <div>
                    <strong onClick={this.goToVote}>你还没有投票,点击去投票</strong>
                </div>;
        } else {
            for (let i in data) {
                let view =
                    <div
                        key={i}
                        style={{
                            width: '100%',
                            height: 30,
                            marginTop: 10,
                            display: 'flex',
                            flexDirection: 'row',
                            alignItems: 'flex-start',
                            justifyContent: 'flex-start',
                        }}>
                        <strong>{parseInt(i) + 1}</strong>
                        <strong
                            style={{
                                paddingLeft: 20
                            }}>{data[i].questionName}</strong>
                        <strong
                            style={{
                                paddingLeft: 20,
                                color: 'blue'
                            }}>{data[i].optionName}</strong>
                    </div>;
                contenView.push(view);
            }
        }
        let createTime = null;
        if (typeof data == 'undefined' || data == null || data == [] || data.length == 0) {
            createTime = null;
        } else {
            createTime = data[0].createTime;
        }

        let timeView =
            <div
                style={{
                    width: '100%',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'flex-start',
                    justifyContent: 'flex-start',
                }}
            >
                <strong>{(typeof createTime != 'undefined' && createTime != null) ? '投票时间：' + createTime : null}</strong>
            </div>

        let leaderView = null;
        if (this.state.isLeader == 0) {
            leaderView = null;
        } else {
            leaderView =
                <div style={{
                    width: '100%',
                    display: 'flex',
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'flex-start',
                    paddingTop: 10
                }}>
                    <div>
                        <button style={{
                            width: 100,
                            height: 30,
                            backgroundColor: 'red',
                            color: 'white',
                            borderWidth: 0
                        }}
                            onClick={this.seedResult}
                        >查看投票结果</button>
                    </div>
                    <div style={{
                        paddingLeft: 20
                    }}>
                        <button style={{
                            width: 100,
                            height: 30,
                            backgroundColor: 'red',
                            color: 'white',
                            borderWidth: 0,
                        }}
                            onClick={this.clearResult}
                        >清空数据</button>
                    </div>
                </div>;
        }




        return (
            <div style={{
                paddingTop: '1em',
                paddingBottom: '1em',
                paddingLeft: '10px',
                paddingRight: '10px',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
            }}>
                <h4>我的投票结果</h4>
                {contenView}
                {timeView}
                {leaderView}
            </div>
        );
    }

    clearResult = () => {
        if (window.confirm("确定清空数据吗？")) {
            this.clearFetch();
            this.setState({ result: [] });
        } else {

        }
    }

    clearFetch = () => {
        let url = baseUrl + '/vote/clearVote'
        fetch(url, {
            credentials: 'include',
            xhrFields: { withCredentials: true },
            crossDomain: true
        }).then((response) => { // 数据解析方式

            if (typeof response == 'undefined' || response == null || response.status == 404) {
                //请求不到数据
                return '数据错误';
            } else {
                return response.json();
            }
        }).then((responseData) => { // 获取到的数据处理
            // 请求不到数据，直接返回
            if (responseData == '数据错误') {
                alert('请求不到数据');
                return;
            }
        }).catch((error) => { // 错误处理
            if (error) {
                alert(error + "");
            }
        });
    }

    seedResult = () => {
        let path = {
            pathname: '/result'
        }
        this.props.history.push(path);
    }
}

export default Vote;
