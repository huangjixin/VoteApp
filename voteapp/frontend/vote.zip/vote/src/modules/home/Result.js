import React, { Component } from 'react';
import Base from '../../resource/Base';

const baseUrl = Base.baseUrl;
class Result extends Component {

    constructor(props) {
        super(props);
        this.state = {
            result: []
        }
    }

    componentDidMount = () => {
        this.votedResultRequest();
    }




    votedResultRequest = () => {
        let url = baseUrl + '/vote/selectVoteResult';

        fetch(url, {
            credentials: 'include',
            xhrFields: { withCredentials: true },
            crossDomain: true
        }).then((response) => { // 数据解析方式

            if (typeof response == 'undefined' || response == null || response.status == 404) {
                //请求不到数据
                return '数据错误';
            } else {
                return response.json();
            }
        }).then((responseData) => { // 获取到的数据处理
            // 请求不到数据，直接返回
            if (responseData == '数据错误') {
                alert('请求不到数据');
                return;
            }
            this.setState({ result: responseData });
        }).catch((error) => { // 错误处理
            if (error) {
                alert(error + "");
            }
        });
    }


    render() {

        let contentView = [];
        let data = this.state.result;
        if (typeof data == 'undefined' || data == null || data == [] || data.length == 0) {
            contentView = null;
        } else {
            let questionName = null;
            for (let i in data) {
                if (questionName == null) {
                    questionName = data[i].questionName;
                }


                let view =
                
                    <div
                        key={i}
                        style={{
                            width: '100%',
                            height: 30,
                            marginTop: 10,
                            display: 'flex',
                            flexDirection: 'row',
                            alignItems: 'flex-start',
                            justifyContent: 'flex-start',
                        }}>
                        
                        <strong>{parseInt(i) + 1}</strong>
                        <strong
                            style={{
                                paddingLeft: 20
                            }}>{data[i].questionName}</strong>
                        <strong
                            style={{
                                paddingLeft: 20,
                                color: 'blue'
                            }}>{data[i].optionName}</strong>
                        <strong
                            style={{
                                paddingLeft: 20,
                                color: 'red'
                            }}>{data[i].voteNum == null ? 0 : data[i].voteNum}</strong>
                    </div>;
                    if(questionName != data[i].questionName){
                        let tempView = <br></br>
                        contentView.push(tempView);
                    }
                contentView.push(view);

                questionName = data[i].questionName;
            }
        }

        return (
            <div style={{
                paddingTop: '1em',
                paddingBottom: '1em',
                paddingLeft: '10px',
                paddingRight: '10px',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
            }}>
                <h4>所有票数结果</h4>
                {contentView}
            </div>
        );
    }
}

export default Result;
