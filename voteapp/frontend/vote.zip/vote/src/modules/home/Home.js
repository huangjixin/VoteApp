import React, { Component } from 'react';
import Base from '../../resource/Base';
import '../../css/home/Home.css';

const baseUrl = Base.baseUrl;

let user = null;
let storage = window.sessionStorage;
class Home extends Component {
    constructor(props) {
        super(props);
        this.state = {
            option: [],
            data: [],
            isClicked: false,
            isCheck: [],
            topicId: 1
        }
        let data = storage.getItem('user')
        user = JSON.parse(data);
    }

    componentDidMount() {
        this.requestVoteData();
    }

    requestVoteData = () => {
        let url = baseUrl + '/topic/selectAll';
        fetch(
            url, {
                credentials: 'include',
                xhrFields: { withCredentials: true },
                crossDomain: true
            }
        ).then((response) => { // 数据解析方式

            if (typeof response == 'undefined' || response == null || response.status == 404) {
                //请求不到数据
                return '数据错误';
            } else {
                return response.json();
            }
        }).then((responseData) => { // 获取到的数据处理
            // 请求不到数据，直接返回
            if (responseData == '数据错误') {
                alert('请求不到数据');
                return;
            }
            let data = responseData;
            this.setState({ data: data });
        }).catch((error) => { // 错误处理
            if (error) {
                alert(error + "");
            }
        });
    }


    render() {



        let contenView = [];
        let data = this.state.data;

        if (typeof data != 'undefined' && data != null && data != [] && data.length != 0) {
            for (let i in data) {
                let headerView =
                    <div>
                        <h3 style={{ width: '100%' }}>{data[i].name}</h3>
                        <strong>{user != null ? user.name : null}</strong>
                    </div>;
                contenView.push(headerView);
                let list = data[i].questions;
                if (typeof list != 'undefined' && list != null && list != [] && list.length != 0) {

                    for (let j in list) {
                        //初始化是否选中数组
                        this.state.isCheck[parseInt(j)] = false;
                        if (this.state.topicId != list[j].topicId) {
                            this.state.topicId = list[j].topicId;
                        }
                        let questionId = list[j].id;
                        let num = parseInt(j) + 1;
                        let questionView = <div style={{ paddingTop: 20 }}><strong style={{ float: 'left' }}>{num + '. ' + list[j].name}</strong></div>
                        contenView.push(questionView);
                        let names = list[j].options;
                        for (let k in names) {
                            let optionId = names[k].id;
                            let name = names[k].name;
                            let nameView =
                                <div>
                                    <label
                                        style={{
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'flex-start',
                                        }}
                                    >
                                        <input
                                            style={{
                                                zoom: '150%'
                                            }}
                                            onChange={(e) => { this.handleInputChange(questionId, optionId, e) }}
                                            name={parseInt(j)}
                                            type='radio'
                                            value={name} />
                                        {'   ' + String.fromCharCode(parseInt(k) + 65) + '、' + name}

                                    </label>
                                </div>
                            contenView.push(nameView);
                        }
                    }
                } else {
                    contenView =
                        <div>
                            <strong>暂无数据</strong>
                        </div>;
                }
            }

        } else {
            contenView =
                <div>
                    <strong>暂无数据</strong>
                </div>;
        }

        return (
            <div className='Home'>
                <div style={{
                    width: '100%'
                }}>
                    <form onSubmit={this.handleSubmit}>
                        <div style={{
                            width: '100%',
                            display: 'flex',
                            flexDirection: 'column',
                            paddingTop: '1em',
                            paddingBottom: '1em',
                        }}>

                            {contenView}

                        </div>
                        <div style={{
                            width: '100%',
                            display: 'flex',
                            paddingTop: '1em',
                            paddingBottom: '1em',
                        }}>
                            <input style={{
                                width: '100%',
                                height: 30,
                                backgroundColor: 'red',
                                color: '#FFFFFF',
                                fontSize: '1em',
                                borderRadius: 4,
                                borderWidth: 1
                            }}
                                type='submit'
                                value='提交' />
                        </div>
                    </form>
                </div>
            </div>
        );
    }

    handleInputChange = (questionId, optionId, event) => {
        let target = event.target;
        let index = target.name;
        let check = target.checked;
        this.state.isCheck[index] = check;

        let choose = {
            questionId: questionId,
            optionId: optionId,
            userId: user.id,
            weight: user.weight
        }
        this.state.option[index] = choose;
    }

    handleSubmit = (event) => {
        if (this.state.isClicked) {
            return;
        }

        this.state.isClicked = true;

        for (let i in this.state.isCheck) {
            if (!this.state.isCheck[i]) {
                alert('第' + (parseInt(i) + 1) + '题未选中！');
                this.state.isClicked = false;
                event.preventDefault();
                return;
            }
        }

        if (window.confirm("确定提交吗？")) {
            this.voteFetch(this.state.option);
        } else {
            this.state.isClicked = false;
        }
        event.preventDefault();
    }

    voteFetch = (option) => {
        let url = baseUrl + '/vote/insert?userId=' + user.id + '&topicId=' + this.state.topicId;
        let optionStr = JSON.stringify(option);
        fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                "mode": "cors"
            },
            body: optionStr,
            credentials: 'include',
            xhrFields: { withCredentials: true },
            crossDomain: true
        }).then((res) => {
            if (typeof res == 'undefined' || res == null) {
                return null;
            } else {
                return res.json();
            }
        }).then((data) => {
            if (typeof data == 'undefined' || data == null) {
                alert('提交失败');
                return;
            }
            if (data.code == 200) {
                let path = {
                    pathname: '/voted'
                }
                this.props.history.push(path);
            } else {
                alert(data.message);
            }
            this.state.isClicked = false;
        }).catch(e => {
            this.state.isClicked = false;
            alert(e);
        });
    }
}

export default Home;