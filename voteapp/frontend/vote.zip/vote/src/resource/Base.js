// const baseUrl = 'http://192.168.9.120:8000/vote';
const baseUrl = 'https://frutest.zhiyesoft.cn/vote';
export default { baseUrl };